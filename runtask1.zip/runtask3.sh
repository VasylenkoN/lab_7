gcc task3.c -o task3.hehe -lpthread
./task3.hehe