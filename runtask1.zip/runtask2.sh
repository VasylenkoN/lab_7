gcc task2.c -o task2.hehe -lpthread
./task2.hehe