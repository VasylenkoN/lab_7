gcc task1.c -o task1.hehe -lpthread
./task1.hehe