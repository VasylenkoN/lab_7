gcc task4.c -o task4.hehe -lpthread
./task4.hehe